//
// Created by 王震 on 2016/12/2.
//

#ifndef COMPILER_ERRORINFO_H
#define COMPILER_ERRORINFO_H

#include "Analysis.h"

void errorHandler(int index) ;

#endif //COMPILER_ERRORINFO_H
